class Student {
    name = 'erbol'
    age = 15
    surname = 'tayirbekov'

    constructor ( name ='erbol', age = 15, surname = 'tayirbekov'  ){

        this.name = name
        this.age = age
        this.surname = surname
    }

}

let a = new Student();
console.log(a);

