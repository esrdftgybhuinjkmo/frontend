// try {
//     console.log('try exe');
//     console.log( 5 + 8);
    
//     try {
//         log;
//     } catch (error) {
//         console.log('error 404');
        
//     }
    
// } catch (error) {
//     console.log(error);
    
    
// }

// let username = document.getElementById('username');
// let city = document.getElementById('city');
// let work = document.getElementById('work');





fetch('https://jsonplaceholder.typicode.com/posts ')
    .then((response) =>response.json())
    .then((data) =>{
        data.forEach(user => {
        document.write(`${user.id}, ${user.title},${user.body}`)

            
        });
        

    })
    .catch((error) => console.log(error))